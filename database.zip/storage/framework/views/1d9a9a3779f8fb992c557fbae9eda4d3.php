
<?php $__env->startSection('dashborad_header'); ?>
    <div class="main-content">
        <div class="grid grid-cols-12 gap-x-6 mt-12">
            <div class="col-span-12">
                <div class="box">
                    <div class="box-header">
                        <h5 class="box-title">Add Product Area</h5>
                    </div>
                    <div class="box-body">
                        <form>
                            <div class="">
                                <div class="space-y-2">
                                    <label class="ti-form-label mb-0">Product Name</label>
                                    <input type="text" class="my-auto ti-form-input" placeholder="Product Name">
                                </div>

                            </div>
                            
                            <div class="my-5">

                                <div class="box">
                                    <div class="box-header">
                                        <label class="ti-form-label mb-0">Product Image</label>
                                    </div>
                                    <div>
                                        <label for="file-input-medium" class="sr-only">Choose file</label>
                                        <input type="file" name="file-input-medium" id="file-input-medium"
                                            class="block w-full border border-gray-200 focus:shadow-sm dark:focus:shadow-white/10 rounded-sm text-sm focus:z-10 focus:outline-0 focus:border-gray-200 dark:focus:border-white/10 dark:border-white/10 dark:text-white/70
                                          file:bg-transparent file:border-0
                                          file:bg-gray-100 ltr:file:mr-4 rtl:file:ml-4
                                          file:py-3 file:px-4
                                          dark:file:bg-black/20 dark:file:text-white/70">
                                    </div>
                                </div>

                            </div>
                            <div class="my-5">

                                <div class="box">
                                    <div class="box-header">
                                        <label class="ti-form-label mb-0">Product Gallery</label>
                                    </div>
                                    <div>
                                        <label for="file-input-medium" class="sr-only">Choose file</label>
                                        <input type="file" name="file-input-medium" id="file-input-medium"
                                            class="block w-full border border-gray-200 focus:shadow-sm dark:focus:shadow-white/10 rounded-sm text-sm focus:z-10 focus:outline-0 focus:border-gray-200 dark:focus:border-white/10 dark:border-white/10 dark:text-white/70
                                          file:bg-transparent file:border-0
                                          file:bg-gray-100 ltr:file:mr-4 rtl:file:ml-4
                                          file:py-3 file:px-4
                                          dark:file:bg-black/20 dark:file:text-white/70">
                                    </div>
                                </div>

                            </div>

                            <div class="grid grid-cols-12 gap-6">
                                <div class="col-span-12">
                                    <div class="box">
                                        <div class="box-header">
                                            <label class="ti-form-label mb-0">Product Short Description</label>
                                        </div>
                                        <div class="box-body">

                                            <div id="editor" class="ql-container ql-snow">
                                                <div class="ql-editor" data-gramm="false" contenteditable="true">

                                                </div>
                                                <div class="ql-clipboard" contenteditable="true" tabindex="-1"></div>
                                                <div class="ql-tooltip ql-editing ql-hidden" data-mode="video"
                                                    style="left: 9.0625px; top: 148.953px;"><a class="ql-preview"
                                                        rel="noopener noreferrer" target="_blank"
                                                        href="about:blank"></a><input type="text" data-formula="e=mc^2"
                                                        data-link="https://quilljs.com" data-video="Embed URL"
                                                        placeholder="Embed URL"><a class="ql-action"></a><a
                                                        class="ql-remove"></a></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="grid grid-cols-12 gap-6">
                                <div class="col-span-12">
                                    <div class="box">
                                        <div class="box-header">
                                            <label class="ti-form-label mb-0">Product Short Description</label>
                                        </div>
                                        <div class="box-body">

                                            <div class="space-y-2">
                                                <label class="ti-form-label mb-0">Product Name</label>
                                                <input type="text" class="my-auto ti-form-input"
                                                    placeholder="Product Name">
                                            </div>

                                            <label class="ti-form-label mb-0">Product Image</label>
                                            <div>
                                                <label for="file-input-medium" class="sr-only">Choose file</label>
                                                <input type="file" name="file-input-medium" id="file-input-medium"
                                                    class="block w-full border border-gray-200 focus:shadow-sm dark:focus:shadow-white/10 rounded-sm text-sm focus:z-10 focus:outline-0 focus:border-gray-200 dark:focus:border-white/10 dark:border-white/10 dark:text-white/70
                                                  file:bg-transparent file:border-0
                                                  file:bg-gray-100 ltr:file:mr-4 rtl:file:ml-4
                                                  file:py-3 file:px-4
                                                  dark:file:bg-black/20 dark:file:text-white/70">
                                            </div>


                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="my-5">
                                <div class="space-y-2">
                                    <label class="ti-form-label mb-0">Select Category</label>
                                    <select class="ti-form-select sm:p-4">
                                        <option selected="">Select Category</option>
                                        <?php $__currentLoopData = $allCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->category_title); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="my-5">
                                <div class="space-y-2">
                                    <label class="ti-form-label mb-0">Placement in shop</label>
                                    <input type="text" name="position" class="my-auto ti-form-input"
                                        placeholder="Placement">
                                </div>
                            </div>

                            <div class="my-5">
                                <div class="space-y-2">
                                    <label class="ti-form-label mb-0">Product Status</label>
                                    <select class="ti-form-select sm:p-4">
                                        <option selected="">Active</option>
                                        <option>De-active</option>
                                        <option>Pending</option>
                                    </select>
                                </div>
                            </div>
                            <div class="my-5">
                                <div class="box">
                                    <div class="box-header">
                                        <label class="ti-form-label mb-0">Product Schedule </label>
                                    </div>
                                    <div class="box-body">
                                        <div class="flex rounded-sm shadow-sm">
                                            <div
                                                class="px-4 inline-flex items-center min-w-fit ltr:rounded-l-sm rtl:rounded-r-sm border ltr:border-r-0 rtl:border-l-0 border-gray-200 bg-gray-50 dark:bg-black/20 dark:border-white/10">
                                                <span class="text-sm text-gray-500 dark:text-white/70"><i
                                                        class="ri ri-calendar-line"></i></span>
                                            </div>

                                            <input type="text"
                                                class="ti-form-input ltr:rounded-l-none rtl:rounded-r-none focus:z-10 flatpickr-input"
                                                id="date" placeholder="Choose date" readonly="readonly">
                                        </div>
                                    </div>
                                </div>
                            </div>





                            <button type="submit" class="ti-btn ti-btn-primary">Submit Product</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\laragon\www\ecommerceProject\resources\views/admin/Product/addProduct.blade.php ENDPATH**/ ?>