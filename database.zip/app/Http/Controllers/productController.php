<?php

namespace App\Http\Controllers;

use App\Models\category;
use Illuminate\Http\Request;

class productController extends Controller
{

    function addProduct()
    {
        $allCategory = category::get();
        return view('admin.Product.addProduct', compact('allCategory'));
    }
    function allProduct()
    {
        return view('admin.Product.allProduct');
    }

    function adminIndex()
    {
        return view('admin.dashboard');
    }
}
